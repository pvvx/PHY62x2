package com.phy.ota.sdk.beans;

/**
 * OTAType
 *
 * @author:zhoululu
 * @date:2018/12/13
 */
public enum OTAType {

    OTA,RESOURCE

}
