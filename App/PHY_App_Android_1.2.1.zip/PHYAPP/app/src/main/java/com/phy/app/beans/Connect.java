package com.phy.app.beans;

/**
 * Connect
 *
 * @author:zhoululu
 * @date:2018/4/16
 */

public class Connect {

    private boolean connect;

    public Connect(boolean connect) {
        this.connect = connect;
    }

    public boolean isConnect() {
        return connect;
    }
}
