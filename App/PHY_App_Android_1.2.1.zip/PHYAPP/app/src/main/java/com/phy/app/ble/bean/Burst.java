package com.phy.app.ble.bean;

/**
 * Burst
 *
 * @author:zhoululu
 * @date:2018/5/19
 */

public class Burst {



}
